//
//  MyBatteryMonitor.h
//  360 Driver
//
//  Created by Pierre TACCHI on 21/01/15.
//

#import <Cocoa/Cocoa.h>

@interface MyBatteryMonitor : NSView

@property (nonatomic) int bars;
@property (nonatomic) int percentage;

@end
