//
//  MyTrigger.h
//  360 Driver
//
//  Created by Pierre TACCHI on 21/01/15.
//

#import <Cocoa/Cocoa.h>

@interface MyTrigger : NSView

@property (nonatomic, strong) NSString *name;
@property (nonatomic) int val;

@end
