# Logitech-F710-wireless-gamepad-interfacing-with-Arduino
Interfacing Logitech F710 wireless gamepad with Arduino

The following code is for reading logitech F710 wireless gaming console buttons with Arduino.
Repository contents:
  i. Arduino Program for reading keys.
  ii. hidjoystickrptparser.cpp
  iii. hidjoystickrptparser.h
  
Thank You
