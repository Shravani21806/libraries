// SPDX-License-Identifier: Apache-2.0
// Copyright 2023 Ricardo Quesada
// http://retro.moe/unijoysticle2

#include "uni_console.h"

void uni_console_init(void) {
    // FIXME: Implement me
}
