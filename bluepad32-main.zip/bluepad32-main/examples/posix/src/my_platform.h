#ifndef MY_PLATFORM
#define MY_PLATFORM

#include <uni.h>

struct uni_platform* get_my_platform(void);

#endif  // MY_PLATFORM
