# Examples

These examples show how to use Bluepad32 for the different platforms.

Each folder has a `README.md` with install / compile / flash instructions.
