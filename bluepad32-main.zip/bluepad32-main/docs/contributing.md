{%
    include "../CONTRIBUTING.md"
%}
