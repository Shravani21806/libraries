{%
    include "../LICENSE"
    start="<!--intro-start-->"
    end="<!--intro-end-->"
%}