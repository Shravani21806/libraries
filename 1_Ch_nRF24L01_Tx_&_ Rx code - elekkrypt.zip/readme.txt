This compressed file contains:
1. code for 1 channel transmitter and receiver using nrf24l01 module
2. rf24-master library for nrf module

https://dhirajkushwaha.com/elekkrypt
https://youtube.com/elekkrypt


---- code written by Dhiraj Kushwaha  ----

file last updated on 210713;

