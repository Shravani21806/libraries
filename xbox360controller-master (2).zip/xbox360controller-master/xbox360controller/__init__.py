from xbox360controller.controller import Xbox360Controller

__author__ = "Linus Groh"
__version__ = "1.1.2"
__all__ = ["Xbox360Controller"]
