# xbox360controller Documentation

See [`API.md`](https://github.com/linusg/xbox360controller/blob/master/docs/API.md) for a API reference.